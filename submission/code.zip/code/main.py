"""GhostLedger CLI: audit every deletion request and write output.csv at the repository root.

    python code/main.py                       # full evaluation set -> ./output.csv
    python code/main.py --requests sample_deletion_requests.csv --out .scratch/sample_pred.csv
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ghostledger import contract  # noqa: E402
from ghostledger.integrity import IntegrityError, check  # noqa: E402
from ghostledger.io import load_dataset  # noqa: E402
from ghostledger.pipeline import Auditor, Config, write_output  # noqa: E402

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRATCH = os.path.join(REPO, ".scratch")


def inside(path, root):
    """True when path resolves to root or below it (symlinks, '..', case and separators normalized).
    A sibling such as .scratch_x or a path on another drive is outside."""
    p, r = (os.path.normcase(os.path.realpath(x)) for x in (path, root))
    try:
        return os.path.commonpath([p, r]) == r
    except ValueError:  # different drives on Windows
        return False


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", default=os.path.join(REPO, "dataset"))
    p.add_argument("--requests", default="deletion_requests.csv")
    p.add_argument("--out", default=os.path.join(REPO, "output.csv"))
    p.add_argument("--identity-horizon", choices=["any", "audit"], default="any")
    p.add_argument("--all-accounts", action="store_true", help="keep every linked account, not only the latest")
    p.add_argument("--drop-stale-absent", action="store_true")
    p.add_argument("--use-candidates", action="store_true", help="diagnostic: allow workflow-correlation links")
    p.add_argument("--no-worker-attribution", dest="worker_attribution", action="store_false",
                   help="disable forced-edge worker-row account attribution (on by default)")
    p.add_argument("--temporal", choices=["retrospective", "strict"], default="retrospective",
                   help="experimental strict: every identity/link/matching input cut off at audit_at")
    a = p.parse_args(argv)
    if a.temporal != "retrospective" and not inside(a.out, SCRATCH):
        sys.exit(f"--temporal {a.temporal} is experimental; write candidate output under {SCRATCH}")
    t0 = time.perf_counter()
    ds = load_dataset(a.dataset, a.requests)
    cfg = Config(a.identity_horizon, not a.all_accounts, a.drop_stale_absent, a.use_candidates, a.worker_attribution,
                 a.temporal)
    auditor = Auditor(ds, cfg)
    try:
        integrity = check(auditor.index)
    except IntegrityError as e:
        sys.exit(str(e))
    results = auditor.run()
    try:
        write_output(results, a.out, gate=contract.gate(ds.requests, contract.corpus(ds, auditor.index)),
                     order=[r["case_id"] for r in ds.requests])
    except contract.ContractError as e:
        sys.exit(str(e))
    counts = {}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1
    print(f"wrote {len(results)} rows to {a.out} {counts} in {time.perf_counter() - t0:.1f}s; "
          f"observations={len(auditor.index.observations)} unparsed_files="
          f"{sum(1 for v in auditor.index.file_status.values() if v != 'parsed')}; integrity={integrity['counts']}; "
          f"model_calls=0")
    return results


if __name__ == "__main__":
    main()
