"""Experimental (Phase 3, H2): attribute deletion-worker account rows to requests by global assignment.

A deletion-worker DELETE_RECORD row on account_* is a candidate for a request when it falls inside
[max(requested_at, reported_at - LEAD), reported_at + SLACK] and its reported_result is compatible
with the request's reported_status. Rows whose resource is identifier-linked to another request are
excluded, as are rows whose account carries identifiers of users other than the requester
(Phase 7 veto: an account whose evidence names someone else is never attributed by timing), and
requests that already have exactly one identifier-linked candidate row are settled.
An edge is accepted only if it belongs to every maximum matching of the remaining bipartite graph
(Dulmage-Mendelsohn: matched edge not on an alternating cycle and not reachable from a free vertex),
so an ambiguous row is never assigned. On by default since Phase 7 (Config(worker_attribution=False) disables).
"""
import glob
import os
from collections import defaultdict
from datetime import datetime, timedelta

from .intent import classify
from .io import read_csv

LEAD = timedelta(minutes=80)
SLACK = timedelta(minutes=10)
COMPAT = {"COMPLETE": {"SUCCESS"}, "NOT_STARTED": {"FAILED"}, "PARTIALLY_COMPLETE": {"PARTIAL", "SUCCESS"}}


def _t(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")


def request_pool(root):
    """Every participant-facing request file in the dataset; worker rows are shared across them."""
    seen = {}
    for path in sorted(glob.glob(os.path.join(root, "*deletion_requests.csv"))):
        for r in read_csv(path):
            seen.setdefault(r["case_id"], r)
    return list(seen.values())


def identifier_users(graph):
    """identifier -> user_ids, over every user's current and historical identifiers."""
    out = defaultdict(set)
    for u, row in graph.users.items():
        for i in graph.subject(row["email"]).identifiers:
            out[i].add(u)
    return out


def account_users(graph, rid, id_users, as_of=None):
    """Users named by any identifier on the account's observations or catalog rows (as_of: known by then)."""
    ids = set()
    for o in graph.index.by_resource.get(rid, ()):
        if as_of is None or (o.file_captured_at <= as_of and (o.observed_at or o.file_captured_at) <= as_of):
            ids |= o.identifiers
    for _, at, cids in graph.catalog.get(rid, ()):
        if as_of is None or at <= as_of:
            ids |= cids
    return set().union(*(id_users.get(i, ()) for i in ids)) if ids else set()


def edges(dataset, graph, pool, as_of=None):
    """as_of (experimental strict cutoff): only requests reported, rows logged and identity facts
    recorded at or before as_of take part, so later activity cannot change an earlier assignment."""
    reqs = [r for r in pool if classify(r["request_text"])[0] and (as_of is None or r["reported_at"] <= as_of)]
    rows = {a["activity_id"]: a for a in dataset.activity
            if a["source_system"] == "deletion_worker" and a["resource_id"].startswith("account_")
            and a["event_type"] == "DELETE_RECORD" and (as_of is None or a["event_time"] <= as_of)}
    owners = defaultdict(set)
    for r in reqs:
        if as_of is None:
            linked = graph.links(graph.subject(r["email"]))
        else:
            linked = graph.links(graph.subject(r["email"], as_of), lambda o: o.file_captured_at <= as_of
                                 and (o.observed_at or o.file_captured_at) <= as_of, as_of)
        for rid in linked:
            owners[rid].add(r["case_id"])
    id_users = identifier_users(graph)
    named = {rid: account_users(graph, rid, id_users, as_of) for rid in {a["resource_id"] for a in rows.values()}}
    req_users = {r["case_id"]: (graph.subject(r["email"]) if as_of is None else graph.subject(r["email"], as_of)).user_ids
                 for r in reqs}
    cand = defaultdict(set)
    for aid, a in rows.items():
        t = _t(a["event_time"])
        for r in reqs:
            others = named[a["resource_id"]]
            if others and not others & req_users[r["case_id"]]:
                continue   # the account's own evidence names a different user
            lo = max(_t(r["requested_at"]), _t(r["reported_at"]) - LEAD)
            if lo <= t <= _t(r["reported_at"]) + SLACK and a["reported_result"] in COMPAT.get(r["reported_status"], ()):
                cand[r["case_id"]].add(aid)
    settled = {}
    for cid, es in cand.items():
        own = [aid for aid in es if cid in owners.get(rows[aid]["resource_id"], ())]
        if len(own) == 1:
            settled[cid] = own[0]
    taken = set(settled.values())
    open_ = {cid: {aid for aid in es if aid not in taken and not (owners.get(rows[aid]["resource_id"], set()) - {cid})}
             for cid, es in cand.items() if cid not in settled}
    return rows, open_


def _max_matching(E):
    match_r = {}

    def augment(c, seen):
        for a in sorted(E[c]):
            if a in seen:
                continue
            seen.add(a)
            if a not in match_r or augment(match_r[a], seen):
                match_r[a] = c
                return True
        return False

    for c in sorted(E):
        augment(c, set())
    return {c: a for a, c in match_r.items()}


def _sccs(nodes, adj):
    index, low, on, stack, comp, out, n = {}, {}, set(), [], {}, 0, [0]
    for root in nodes:
        if root in index:
            continue
        work = [(root, iter(adj.get(root, ())))]
        index[root] = low[root] = n[0]; n[0] += 1; stack.append(root); on.add(root)
        while work:
            v, it = work[-1]
            w = next(it, None)
            if w is not None:
                if w not in index:
                    index[w] = low[w] = n[0]; n[0] += 1; stack.append(w); on.add(w)
                    work.append((w, iter(adj.get(w, ()))))
                elif w in on:
                    low[v] = min(low[v], index[w])
                continue
            work.pop()
            if work:
                low[work[-1][0]] = min(low[work[-1][0]], low[v])
            if low[v] == index[v]:
                while True:
                    w = stack.pop(); on.discard(w); comp[w] = out
                    if w == v:
                        break
                out += 1
    return comp


def forced_edges(E):
    """Edges contained in every maximum matching of the bipartite graph E: request -> {row}."""
    M = _max_matching(E)
    adj = defaultdict(set)              # unmatched edges request->row, matched edges row->request
    for c, rs in E.items():
        for a in rs:
            if M.get(c) == a:
                adj[("r", a)].add(("c", c))
            else:
                adj[("c", c)].add(("r", a))
    rev = defaultdict(set)
    for v, ws in adj.items():
        for w in ws:
            rev[w].add(v)
    matched_rows = set(M.values())
    free = [("c", c) for c in E if c not in M] + [("r", a) for rs in E.values() for a in rs if a not in matched_rows]

    def reach(starts, g):
        seen, todo = set(starts), list(starts)
        while todo:
            for w in g.get(todo.pop(), ()):
                if w not in seen:
                    seen.add(w); todo.append(w)
        return seen

    from_free_c = reach([v for v in free if v[0] == "c"], adj)   # even alternating paths from free requests
    to_free_r = reach([v for v in free if v[0] == "r"], rev)     # even alternating paths to free rows
    nodes = sorted(set(adj) | set(rev))
    comp = _sccs(nodes, adj)
    return {c: a for c, a in M.items()
            if comp[("c", c)] != comp[("r", a)] and ("r", a) not in from_free_c and ("c", c) not in to_free_r}


def attribute(dataset, graph, pool, as_of=None):
    """case_id -> (resource_id, activity_id) for unambiguously attributed primary-account rows."""
    rows, open_ = edges(dataset, graph, pool, as_of)
    return {c: (rows[a]["resource_id"], a) for c, a in forced_edges(open_).items()}
