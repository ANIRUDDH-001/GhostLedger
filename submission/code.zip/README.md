# GhostLedger — Ghost Data Still Exists (HackerRank Orchestrate, October 2026)

GhostLedger audits whether a person's data was actually deleted. For every request in
`dataset/deletion_requests.csv` it decides `COMPLETE`, `INCOMPLETE` or `NOT_APPLICABLE` and emits the
ordered `FINDING` → `REMEDIATION` → `VERIFICATION` steps, citing only evidence available at `audit_at`.

The final submitted run is fully deterministic and makes **0 model calls**. An optional LLM
investigator (`code/ghostledger/agent/`, Gemini / Groq) was piloted during development; it is not part
of the run that produced `output.csv` (see `code/evaluation/usage_report.md`).

## Setup

Python 3.10+ (developed on 3.12). One third-party dependency, used to read PDF evidence:

```bash
python -m pip install -r code/requirements.txt
```

`httpx` is needed only for the optional, disabled-by-default LLM pilot (`code/evaluation/agent_pilot.py`).
No API keys are needed for the main run.

## Run

Place the challenge `dataset/` folder at the repository root (next to `code/`), then:

```bash
python code/main.py
```

This writes `output.csv` (518 rows, sorted by `case_id`, header `case_id,deletion_status,steps_json`)
at the repository root. A contract gate validates every row before an atomic write; a failure exits
non-zero and leaves any previous `output.csv` untouched.

Options: `--dataset <dir>` (dataset elsewhere), `--requests sample_deletion_requests.csv`,
`--out <path>`. Run `python code/main.py --help` for the diagnostic flags.

Public sample evaluation (32 cases against `dataset/sample_output.csv`):

```bash
python code/evaluation/evaluate.py --out-dir .scratch/eval
```

Tests (synthetic fixtures; no dataset files are modified):

```bash
python -m pip install pytest
python -m pytest code/tests -q
```

## Architecture

`code/ghostledger/`:

| Module | Role |
| --- | --- |
| `io.py` | loads the CSV inputs |
| `intent.py` | does `request_text` authorize deletion? (multilingual rules; non-deletion → `NOT_APPLICABLE`) |
| `evidence.py` | parses JSON, logs, text records, SQL snapshots (SQLite) and PDFs into typed observations; PNG screenshots are structurally checked but not OCR'd (no OCR backend in the default run) |
| `identity.py`, `attribution.py` | current + historical identifier graph (audit log, hashes, resource links) |
| `state.py` | state of each resource **at `audit_at`**: latest eligible direct sighting; omission-based absence only from an enumerating capture taken after the last operation |
| `policy.py` | applies `deletion_rules.csv` (DELETE / REDACT / ANONYMIZE / RETAIN / tombstone) |
| `pipeline.py` | per-case orchestration, decisions, unresolved accounting |
| `steps.py` | ordered, deterministic step serialization |
| `ledger.py`, `proof.py` | obligation ledger and proof model used for qualification (PROVEN_COMPLIANT / PROVEN_VIOLATION / UNRESOLVED) |
| `contract.py`, `integrity.py`, `safeio.py` | output contract gate, input integrity checks, atomic writes |
| `agent/` | optional LLM investigator (not used in the final run) |

Key semantics:

- Workflow statuses and activity results are claims; only evidence establishes state.
- A capture that merely does not list a record proves absence (DELETE) but never proves that a record
  was **redacted** or **anonymized**; a record policy preserves is never declared preserved when missing.
- Filtered listings (a capture that omits records known to be live) are not treated as exhaustive.
- The output schema has no "unknown" status: when a COMPLETE case contains an obligation the evidence
  cannot prove, no verification step is invented for it and the gap is recorded in the trace.

## Layout

```text
README.md                 this file
code/main.py              entry point
code/requirements.txt
code/ghostledger/         solution package
code/evaluation/          evaluate.py, evaluation_report.md, usage_report.md, diagnostics
code/tests/               synthetic regression tests
```
